# Suzlu


# Development setup

Please install Hugo for your platform via following link: https://gohugo.io/getting-started/installing/


# RUn
Once Hugo is installed, run the following command in the project root directory:
```
    hugo server -D
```